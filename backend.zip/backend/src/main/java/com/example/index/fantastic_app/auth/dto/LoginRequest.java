package com.example.index.fantastic_app.auth.dto;

public record LoginRequest(String username, String password) {
}
